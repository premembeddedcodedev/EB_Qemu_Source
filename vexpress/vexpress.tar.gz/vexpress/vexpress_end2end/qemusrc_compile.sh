./configure --target-list=arm-softmmu,arm-linux-user
make -j 2
make install
