make ARCH=arm CROSS_COMPILE=arm-linux-gnueabihf- vexpress_defconfig
