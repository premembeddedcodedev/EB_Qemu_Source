#ifndef ASM_PARISC_MCKINLEY_H
#define ASM_PARISC_MCKINLEY_H
#ifdef __KERNEL__

/* declared in arch/parisc/kernel/setup.c */
extern struct proc_dir_entry * proc_mckinley_root;

#endif /*__KERNEL__*/
#endif /*ASM_PARISC_MCKINLEY_H*/
