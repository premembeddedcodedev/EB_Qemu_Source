#ifndef __ASM_PARISC_VGA_H__
#define __ASM_PARISC_VGA_H__

/* nothing */

#endif __ASM_PARISC_VGA_H__
