#ifndef __PARISC_CPUTIME_H
#define __PARISC_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __PARISC_CPUTIME_H */
