#ifndef __ASMPARISC_AUXVEC_H
#define __ASMPARISC_AUXVEC_H

#endif
