#include <asm-generic/audit_dir_write.h>
__NR_acct,
__NR_swapon,
__NR_quotactl,
__NR_truncate,
#ifdef __NR_truncate64
__NR_truncate64,
#endif
#ifdef __NR_bind
__NR_bind,		/* bind can affect fs object only in one way... */
#endif
