#ifndef _ASM_M32R__AUXVEC_H
#define _ASM_M32R__AUXVEC_H

#endif  /* _ASM_M32R__AUXVEC_H */
