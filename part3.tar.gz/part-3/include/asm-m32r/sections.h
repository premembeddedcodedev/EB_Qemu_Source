#ifndef _M32R_SECTIONS_H
#define _M32R_SECTIONS_H

/* nothing to see, move along */
#include <asm-generic/sections.h>

#endif	/* _M32R_SECTIONS_H */
