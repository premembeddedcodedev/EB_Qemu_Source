#ifndef _ASM_M32R_RESOURCE_H
#define _ASM_M32R_RESOURCE_H

#include <asm-generic/resource.h>

#endif  /* _ASM_M32R_RESOURCE_H */
