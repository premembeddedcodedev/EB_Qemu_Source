#ifndef _ASM_M32R_PCI_H
#define _ASM_M32R_PCI_H

#include <asm-generic/pci.h>

#define PCI_DMA_BUS_IS_PHYS	(1)

#endif /* _ASM_M32R_PCI_H */
