#ifndef _M32R_BUG_H
#define _M32R_BUG_H
#include <asm-generic/bug.h>
#endif
