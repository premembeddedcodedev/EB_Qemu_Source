#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

#define __ALIGN		.balign 4
#define __ALIGN_STR	".balign 4"

#endif /* __ASM_LINKAGE_H */
