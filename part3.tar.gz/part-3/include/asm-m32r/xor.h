#ifndef _ASM_M32R_XOR_H
#define _ASM_M32R_XOR_H

#include <asm-generic/xor.h>

#endif  /* _ASM_M32R_XOR_H */
