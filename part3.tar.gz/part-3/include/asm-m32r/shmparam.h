#ifndef _ASM_M32R_SHMPARAM_H
#define _ASM_M32R_SHMPARAM_H

#define	SHMLBA PAGE_SIZE		 /* attach addr a multiple of this */

#endif /* _ASM_M32R_SHMPARAM_H */
