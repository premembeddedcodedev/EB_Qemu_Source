#ifndef __SPARC64_CPUTIME_H
#define __SPARC64_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __SPARC64_CPUTIME_H */
