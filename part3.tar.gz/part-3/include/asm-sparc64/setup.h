/*
 *	Just a place holder. 
 */

#ifndef _SPARC64_SETUP_H
#define _SPARC64_SETUP_H

#define COMMAND_LINE_SIZE	2048

#endif /* _SPARC64_SETUP_H */
