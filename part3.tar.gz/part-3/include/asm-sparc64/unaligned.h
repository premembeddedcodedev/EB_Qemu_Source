#ifndef _ASM_SPARC64_UNALIGNED_H_
#define _ASM_SPARC64_UNALIGNED_H_

#include <asm-generic/unaligned.h>

#endif /* _ASM_SPARC64_UNALIGNED_H */
