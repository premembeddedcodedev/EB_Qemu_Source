#ifndef __ASM_SPARC64_AUXVEC_H
#define __ASM_SPARC64_AUXVEC_H

#endif /* !(__ASM_SPARC64_AUXVEC_H) */
