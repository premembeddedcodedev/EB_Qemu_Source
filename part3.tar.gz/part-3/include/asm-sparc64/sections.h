#ifndef _SPARC64_SECTIONS_H
#define _SPARC64_SECTIONS_H

/* nothing to see, move along */
#include <asm-generic/sections.h>

extern char _start[];

#endif
